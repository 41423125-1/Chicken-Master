test = {
  'name': 'filter',
  'points': 1,
  'suites': [
    {
      'scored': True,
      'setup': """
      scm> (load-all ".")
      """,
      'type': 'scheme',
      'cases': [
        {
          'code': """
          scm> (filter even? (list 1 2 3 4 5))
          (2 4)
          """,
          'hidden': False
        },
        {
          'code': """
          scm> (filter (lambda (x) (> x 3)) (list 1 2 3 4 5))
          (4 5)
          """,
          'hidden': False
        }
      ]
    }
  ]
}