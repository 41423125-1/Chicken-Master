test = {
  'name': 'concatenate',
  'points': 1,
  'suites': [
    {
      'scored': True,
      'setup': """
      scm> (load-all ".")
      """,
      'type': 'scheme',
      'cases': [
        {
          'code': """
          scm> (concatenate (list (list 1 2) (list 5 1)))
          (1 2 5 1)
          """,
          'hidden': False
        },
        {
          'code': """
          scm> (concatenate (list (list 1 2) (list)))
          (1 2)
          """,
          'hidden': False
        },
        {
          'code': """
          scm> (define (tail-list n so-far)
          ....   (if (= n 0)
          ....       so-far
          ....       (tail-list (- n 1) (cons 1 so-far)))) ; What does scheme return after a `define` statement?
          tail-list
          scm> (define big-list (tail-list 100000 '()))
          big-list
          scm> (define result (concatenate (list big-list (list 1 2 3 4)))) ; Test for tail recursion
          result
          """,
          'hidden' : False
        }
      ]
    }
  ]
}