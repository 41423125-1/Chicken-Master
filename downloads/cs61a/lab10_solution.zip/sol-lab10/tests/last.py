test = {
  'name': 'last',
  'points': 1,
  'suites': [
    {
      'type': 'scheme',
      'cases': [
        {
          'locked': False,
          'code': r"""
          scm> (last (list 1))
          1
          scm> (last (list (list 1 2) (list 3 4) (list 5 6)))
          (5 6)
          scm> (last (list 1 2 3 4 5))
          5
          scm> (define (make-list n)
          ....    (define (helper i sofar)
          ....      (if (= i 0)
          ....          sofar
          ....          (helper (- i 1) (cons i sofar))))
          ....    (helper n nil))
          make-list
          scm> (last (make-list 50000)) ; Test for tail recursion
          50000
          """,
        },
      ],
      'setup': r"""
      scm> (load-all ".")
      """,
    },
  ]
}